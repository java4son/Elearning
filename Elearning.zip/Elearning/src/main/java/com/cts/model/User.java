package com.cts.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import org.springframework.stereotype.Component;

@Entity
@Component
public class User {
                
                @Id
                @GeneratedValue(strategy=GenerationType.AUTO)
                private int id;
                @Min(value=18,message="age must be atleast 18")
                private int age;
                @NotEmpty(message="Name cannot be null")
                @Pattern(regexp="^[a-zA-Z]{4,}$", message="name should be greater than 4 and not contain number and special numbers")
                private String name;
                @Pattern(regexp="^[0-9]{10}$", message ="must be in the proper format")
                @NotEmpty(message="contact number cannot be empty")
                private String contact;
                @NotEmpty(message="Email cannot be empty")
                @Pattern(regexp="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$", message="Email should be in a proper format")
                @Column(unique=true)
                private String email;
                @NotEmpty(message="Address is required")
                private String address;
                @NotEmpty(message="Name cannot be empty")
                private String notification_status = "active";
                
                private String notification = null;
                @NotEmpty(message="role")
                private String role;
                @NotEmpty(message="Password is required")
                private String password;
                @Transient
                @NotEmpty(message="Password and confirm password must be same")
                private String cpassword;
                private double money=900;
                public String getCpassword() {
					return cpassword;
				}
				public void setCpassword(String cpassword) {
					this.cpassword = cpassword;
				}
				@NotEmpty
                private String account_status = "active";
                
                
                public String getAccount_status() {
                                return account_status;
                }
                public void setAccount_status(String account_status) {
                                this.account_status = account_status;
                }
                
                public double getMoney() {
					return money;
				}
				public void setMoney(double money) {
					this.money = money;
				}
				public String getPassword() {
                                return password;
                }
                public void setPassword(String password) {
                                this.password = password;
                }
                public int getId() {
                                return id;
                }
                public void setId(int id) {
                                this.id = id;
                }
                public int getAge() {
                                return age;
                }
                public void setAge(int age) {
                                this.age = age;
                }
                public String getName() {
                                return name;
                }
                public void setName(String name) {
                                this.name = name;
                }
                public String getContact() {
                                return contact;
                }
                public void setContact(String contact) {
                                this.contact = contact;
                }
                public String getEmail() {
                                return email;
                }
                public void setEmail(String email) {
                                this.email = email;
                }
                public String getAddress() {
                                return address;
                }
                public void setAddress(String address) {
                                this.address = address;
                }
                public String getNotification_status() {
                                return notification_status;
                }
                public void setNotification_status(String notification_status) {
                                this.notification_status = notification_status;
                }
                public String getNotification() {
                                return notification;
                }
                public void setNotification(String notification) {
                                this.notification = notification;
                }
                public String getRole() {
                                return role;
                }
                public void setRole(String role) {
                                this.role = role;
                }
				@Override
				public String toString() {
					return "User [id=" + id + ", age=" + age + ", name=" + name + ", contact=" + contact + ", email="
							+ email + ", address=" + address + ", notification_status=" + notification_status
							+ ", notification=" + notification + ", role=" + role + ", password=" + password
							+ ", cpassword=" + cpassword + ", money=" + money + ", account_status=" + account_status
							+ "]";
				}
                
                



	
}
