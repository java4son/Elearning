package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.model.Transactions;

@Repository
public interface TransactionRepository extends JpaRepository<Transactions, Integer> {
       @Query("select t from Transactions t where user_id = ?1")
       List<Transactions> findByUser_id(int user_id);
       
       @Query("select t from Transactions t where vendor_id = ?1")
       List<Transactions> findByVendor_id(int vendor_id);
       
       @Query("select t,c,u from Transactions t,Courses c,User u where u.id=t.user_id and c.id=t.course_id")
       List findAllTrans();
       
       @Query("select t,c,u from Transactions t,Courses c,User u where u.name = ?1 and u.id=t.user_id and c.id=t.course_id")
       List findAllTransactions(String name);
}

