package com.cts.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.model.Login;
import com.cts.model.User;

@Repository
public interface LoginRepository  extends JpaRepository<Login, Integer> {
	Login findByEmailId(String email);
	}
