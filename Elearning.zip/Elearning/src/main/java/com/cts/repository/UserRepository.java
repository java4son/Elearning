package com.cts.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.model.Login;
import com.cts.model.User;

@Repository
@Transactional
public interface UserRepository extends JpaRepository<User, Integer> {
	
	@Modifying
	@Query("update User set account_status=?1 where id=?2")
	void updateAccountStatus(String account_status,int id);
       User findByEmail(String email);
       User findById(int id);
       @Query("SELECT u FROM User u WHERE role=?1")
       List<User> findRole(String role);
       
    @Modifying
   	@Query("update User set age=?1 ,contact=?2 , address=?3 where id=?4")
   	void updateUserData(int age, String contact,String address,int id);
}

