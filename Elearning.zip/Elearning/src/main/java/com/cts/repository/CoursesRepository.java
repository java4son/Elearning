package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.model.Courses;

@Repository
public interface CoursesRepository extends JpaRepository<Courses, Integer>{

	@Query("SELECT u FROM Courses u WHERE course_name=?1")
	List<Courses> findCourses(String a);
	

	@Query("SELECT u FROM Courses u WHERE u.vendor_id=?1")
	List<Courses> findCourses(int b);
	
	@Query("SELECT u FROM Courses u WHERE u.category=?1")
	List<Courses> findCoursesByCategory(String category);

	Courses findById(int id);
	
	@Query("SELECT c FROM Courses c WHERE c.id in(SELECT course_id FROM Transactions WHERE user_id=?1 AND status='Successfull')")
	List<Courses> findUserCourses(int user_id);


	@Query("SELECT c FROM Courses c WHERE c.id=?1 and vendor_id=?2")
	Courses isVendors(int courseId, int id);


	}