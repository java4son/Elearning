package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.model.Courses;
import com.cts.model.Review;
import com.cts.model.User;
import com.cts.repository.CoursesRepository;
import com.cts.repository.UserRepository;
import com.cts.service.CommonService;
import com.cts.service.LoginService;
import com.cts.service.UserService;
import com.cts.service.VendorService;

@Controller
public class UserController{

	@Autowired
	VendorService vendorService;
	@Autowired
	LoginService loginService;
	@Autowired
	UserService userService;
	@Autowired
	UserRepository userRepository;
	@Autowired
	CoursesRepository coursesRepository;
	@Autowired
	CommonService commonService;
	
	@RequestMapping("/buy")
		public String buyCourse(@RequestParam("course_id") int course_id,@RequestParam("user_id") int user_id,Model model) {
			int flag=userService.purchase(user_id, course_id);
			Courses course=commonService.courseDetails(course_id);
			List<Review> rlist=commonService.getReviewList(course.getId());
			model.addAttribute("reviewObj",new Review());
			model.addAttribute("rlist", rlist);
			model.addAttribute("course", course);
			if(flag==1)	
			return "CourseDetails";
			else if(flag==0)
				return "Failed";
			return "Already";
		}


	@RequestMapping("/getCourse")
		public String getCourse2(@RequestParam int id,Model model) {
			Courses course=commonService.courseDetails(id);
			List<Review> rlist=commonService.getReviewList(id);
			Review review=new Review();
			model.addAttribute("reviewObj",review);
			model.addAttribute("course", course);
			model.addAttribute("rlist", rlist);
			return "CourseDetails";
		}
		
		@RequestMapping("/deleteCourse")
		public String deleteCourse(@RequestParam int id,Model model) {
			coursesRepository.deleteById(id);
			return "CourseDetails";
		}
		
		@RequestMapping("/updateCourse")
		public String updateCourse(@ModelAttribute("course") Courses course, BindingResult result,Model model) {
			if(result.hasErrors()) {
			return "CourseDetails";
			}
			List<Review> rlist=commonService.getReviewList(course.getId());
			vendorService.updateCourse(course);
			model.addAttribute("reviewObj",new Review());
			model.addAttribute("rlist", rlist);
			return "CourseDetails";
		}

	@RequestMapping("/addReview")
		public String addReview(@ModelAttribute("review") Review review,BindingResult result){
			
			commonService.saveReview(review);
			
			return "redirect:getCourse?id="+review.getCourse_id();
		}
		
	@RequestMapping("/showService")
	public String service(@ModelAttribute() User user, ModelMap m) {
		 List<Courses> courseList = coursesRepository.findAll();
		 m.addAttribute("plist", courseList);
		 return "online_services";
	}

	@RequestMapping("/CourseDetails")
	public String cDetails(@RequestParam("id") int id,Model model) {
		Courses course = coursesRepository.findById(id);
		model.addAttribute("course", course);
		  return "CourseDetails";
	}

}
