package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.model.Courses;
import com.cts.model.User;
import com.cts.repository.CoursesRepository;
import com.cts.repository.UserRepository;
import com.cts.service.CommonService;

@Controller
public class AdminController {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	CommonService commonService;
	
	@Autowired
	CoursesRepository coursesRepository;
	
	@RequestMapping("/all_user")
	public String allUser(@ModelAttribute("user") User user,Model m){
		List<User> userList = userRepository.findAll();
		m.addAttribute("user_list", userList);
		return "adm_user";
	}
	@RequestMapping("/search_course")
	public String showSearch(@ModelAttribute("course") Courses courses, Model m){
		List<Courses> cList = coursesRepository.findAll();
		m.addAttribute("clist", cList);
		return "CourseSearch";
	}
	@RequestMapping("/search")
	public String getSearch(@RequestParam("group") String cat,@RequestParam("what") String s ,Model m) {
		List<Courses> courseList=commonService.getCourseList(cat, s);
		m.addAttribute("clist", courseList);
		return "CourseSearch";
	}
}
