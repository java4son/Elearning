package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.model.Courses;
import com.cts.model.Transactions;
import com.cts.model.User;
import com.cts.repository.CoursesRepository;
import com.cts.repository.TransactionRepository;
import com.cts.repository.UserRepository;
import com.cts.service.CommonService;
import com.cts.service.UserService;

@Controller
public class AdminController {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	CommonService commonService;
	
	@Autowired
	CoursesRepository coursesRepository;
	
	@Autowired
	TransactionRepository trasactionRepository;
	
	@Autowired
	UserService userService;
		
	@RequestMapping("/all_user")
	public String allUser(@ModelAttribute("user") User user,Model m){
		List<User> userList = userRepository.findAll();
		m.addAttribute("user_list", userList);
		return "adm_user";
	}
	
	@RequestMapping("/filter")
	public String filter(@RequestParam("group") String role, Model m) {
		List<User> userList = userService.getFilterList(role);
		m.addAttribute("user_list",userList);
		return "adm_user";
	}
	
	@RequestMapping("/deactivate")
	public String adminDeactivate(@RequestParam int id,@ModelAttribute("user") User user,BindingResult result, Model m){
		
		user=userService.getUserById(id);
		
		user.setAccount_status("deactivate");
		userRepository.save(user);
		List<User> userList = userRepository.findAll();
		m.addAttribute("user_list", userList);
				return "adm_user";
	}
	
	@RequestMapping("/search_course")
	public String showSearch(@ModelAttribute("course") Courses courses, Model m){
		List<Courses> cList = coursesRepository.findAll();
		m.addAttribute("clist", cList);
		return "CourseSearch";
	}
	@RequestMapping("/search")
	public String getSearch(@RequestParam("group") String cat,@RequestParam("what") String s ,Model m) {
		List<Courses> courseList=commonService.getCourseList(cat, s);
		m.addAttribute("clist", courseList);
		return "CourseSearch";
	}
	
	@RequestMapping("/transactionADM")
	public String allUser(@ModelAttribute("transactions") Transactions transactions,Model m){
		List transactionList = trasactionRepository.findAllTrans();
		m.addAttribute("transaction_list", transactionList);
		return "adm_transaction";
	}
	
	@RequestMapping("/searchTransaction")
	public String searchTransaction(@RequestParam("what") String user_id, Model m) {
		List transactionList = commonService.getAllData(user_id);
		m.addAttribute("transaction_list",transactionList);
		return "adm_transaction";
	}
	
	
}
