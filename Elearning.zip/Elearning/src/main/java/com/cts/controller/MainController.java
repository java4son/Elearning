package com.cts.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.model.Courses;
import com.cts.model.Review;
import com.cts.model.Transactions;
import com.cts.model.User;
import com.cts.repository.CoursesRepository;
import com.cts.repository.TransactionRepository;
import com.cts.repository.UserRepository;
import com.cts.service.CommonService;
import com.cts.service.LoginService;
import com.cts.service.UserService;
import com.cts.service.VendorService;

@Controller
public class MainController {
	@Autowired
	LoginService loginService;
	@Autowired
	UserService userService;
	@Autowired
	UserRepository userRepository;
	@Autowired
	CoursesRepository coursesRepository;
	@Autowired
	CommonService commonService;

	@Autowired
	VendorService vendorService;
	
	HttpSession session;

	@RequestMapping("/")
	public String showPage() {
		return "login";
	}

	@RequestMapping("/pdfView")
	public String view(@RequestParam("id") int id,Model model) {
		Courses course = coursesRepository.findById(id);
		String name=course.getContent();
		model.addAttribute("name",name);
		return "pdf";
	}
	@RequestMapping("/course")
	public String course() {
		return "course";
	}

	@RequestMapping("/showProfile")
	public String vendorProfile(@ModelAttribute("user") User user, Model obj) {
		String name = (String) session.getAttribute("username");
		System.out.println("MMMMM"+name);
		User temp = loginService.userDetails(name);
		if(temp.getRole().equals("user"))obj.addAttribute("edit",true);
		else obj.addAttribute("edit",false);
		temp.setCpassword(temp.getPassword());
		obj.addAttribute("user", temp);
		return "Profile";
	}

	@RequestMapping("/getCourse")
	public String getCourse2(@RequestParam int id, Model model) {
		Courses course=commonService.courseDetails(id);
		List<Review> rlist=commonService.getReviewList(id);
		Review review=new Review();
		model.addAttribute("reviewObj",review);
		model.addAttribute("course", course);
		model.addAttribute("rlist", rlist);
		int userId=(int) session.getAttribute("userId");
		model.addAttribute("userId",userId);
		if(userService.getRole(userId).equals("user"))
		model.addAttribute("edit",true);
		else model.addAttribute("edit",false);
		
		return "CourseDetails";
	}
	
	
	@RequestMapping("/login")
	public String check(@RequestParam("userName") String userName, @RequestParam("password") String password,
			@RequestParam("role") String role, Model m, HttpServletRequest request) {
		User user = loginService.userDetails(userName);

		if (userName.equals(user.getEmail()) && password.equals(user.getPassword())) {
		
			if(user.getAccount_status().equals("active"))
			{
			session = request.getSession();
			session.setAttribute("username", userName);
			session.setAttribute("userId",user.getId());
			session.setAttribute("role", user.getRole());

			session.setAttribute("user", user);
				if (role.equals(user.getRole()))
				{
					

						if (role.equals("user")) {
							List<Courses> courseList = coursesRepository.findUserCourses(user.getId());
							m.addAttribute("plist", courseList);
							return "user_home";
						}
						else if (role.equals("vendor")) {
							List<Courses> courseList = coursesRepository.findCourses(user.getId());
							m.addAttribute("plist", courseList);
							return "vendor_home";
						}
						else {
							return "admin_home";
						}
				}		
			} else
				return "login";
	}
		return null;
	}

	@RequestMapping("/registration")
	public String showRegister(@ModelAttribute("user") User user) {
		
		return "user_register";
	}

	@RequestMapping(value = "/loginPage", method = RequestMethod.POST)
	public String register(@Valid @ModelAttribute("user") User user, BindingResult result, ModelMap model) {
		if (result.hasErrors()) {
			return "user_register";
		} else {
			userRepository.save(user);
			//loginService.saveUserDetails(user);
			return "login";
		}
	}

	/*
	 * public String viewHomeData(Model m){ List<Courses> courseList =
	 * coursesRepository.findAll(); m.addAttribute("course",courseList); return
	 * "index"; }
	 */

	@RequestMapping("/update")
	public String updateProfile(@Valid @ModelAttribute("user") User user, BindingResult result, Model obj) {
		System.out.println(user);
		if (result.hasErrors()) {
			System.out.println(result.getFieldErrors());
			return "login";
		} else {
			commonService.updateProfile(user);
			user.setCpassword(user.getPassword());
			obj.addAttribute("edit",true);
			return "Profile";
		}
	}

	@RequestMapping("/status")
	public String deactivateAccount(@RequestParam int id,@ModelAttribute("user") User user,BindingResult result, Model m){
		
		user=userService.getUserById(id);
		
		user.setAccount_status("deactivate");
		userRepository.save(user);
				return "login";
	}
	
	@RequestMapping("/showHistory")
	public String showHistory(Model obj) {
		String name = (String) session.getAttribute("username");
		User temp = loginService.userDetails(name);
		List<Transactions> historyDetails =historyDetails=userService.getHistoryDetails(temp);
		
		for (Transactions transactions : historyDetails) {
			System.out.println(transactions);
		}
		obj.addAttribute("transaction_list", historyDetails);

		return "History";
	}

	

	@RequestMapping("/logout")
	public String logout() {
		return "logout";
	}

	@RequestMapping("/showHome")
	public String getHome(@ModelAttribute User user,ModelMap m) {
		user=(User) session.getAttribute("user");
		if(session.getAttribute("role").equals("user")) {
			List<Courses> courseList = coursesRepository.findUserCourses(user.getId());
			m.addAttribute("plist", courseList);
			
		return "user_home";}
		else 
			if(session.getAttribute("role").equals("vendor")) {
				List<Courses> courseList = vendorService.vendorCourses(user.getId());
				m.addAttribute("plist", courseList);
				return "vendor_home";}
		
		return "admin_home";
	}
	
	@RequestMapping("/showService")
	public String service( ModelMap m) {
		 List<Courses> courseList = coursesRepository.findAll();
		 m.addAttribute("plist", courseList);
		 m.addAttribute("userId",session.getAttribute("userId"));
		 return "online_services";
	}
}
