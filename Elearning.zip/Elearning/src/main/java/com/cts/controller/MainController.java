package com.cts.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.model.Courses;
import com.cts.model.Transactions;
import com.cts.model.User;
import com.cts.repository.CoursesRepository;
import com.cts.repository.TransactionRepository;
import com.cts.repository.UserRepository;
import com.cts.service.CommonService;
import com.cts.service.LoginService;
import com.cts.service.UserService;
import com.mysql.cj.Session;

@Controller
public class MainController {
	@Autowired
	LoginService loginService;
	@Autowired
	UserService userService;
	@Autowired
	CoursesRepository coursesRepository;
	@Autowired
	CommonService commonService;

	HttpSession session;

	@RequestMapping("/")
	public String showPage() {
		return "login";
	}

	@RequestMapping("/course")
	public String course() {
		return "course";
	}

	@RequestMapping("showProfile")
	public String vendorProfile(@ModelAttribute("user") User user, Model obj) {
		String name = (String) session.getAttribute("username");
		System.out.println("MMMMM"+name);
		User temp = loginService.userDetails(name);
		obj.addAttribute("user", temp);
		return "Profile";
	}

	@RequestMapping("/login")
	public String check(@RequestParam("userName") String userName, @RequestParam("password") String password,
			@RequestParam("role") String role, Model m, HttpServletRequest request) {
		User user = loginService.userDetails(userName);

		if (userName.equals(user.getEmail()) && password.equals(user.getPassword())) {
			if(user.getAccount_status().equals("active")){
			session = request.getSession();
			session.setAttribute("username", userName);
			if (role.equals(user.getRole())) {
				List<Courses> courseList = coursesRepository.findAll();
				m.addAttribute("plist", courseList);

				if (role.equalsIgnoreCase("user")) {
					return "user_home";
				} else if (role.equalsIgnoreCase("vendor")) {
					return "user_home";
				}
				return "user_home";
				
			} else {
				return "user_home";
			}
		} else
			return "login";
	}
		return null;
	}

	@RequestMapping("/registration")
	public String showRegister(@ModelAttribute("user") User user) {
		
		return "user_register";
	}

	@RequestMapping(value = "/loginPage", method = RequestMethod.POST)
	public String register(@Valid @ModelAttribute("user") User user, BindingResult result, ModelMap model) {
		if (result.hasErrors()) {
			return "user_register";
		} else {
			loginService.saveUserDetails(user);
			return "login";
		}
	}

	/*
	 * public String viewHomeData(Model m){ List<Courses> courseList =
	 * coursesRepository.findAll(); m.addAttribute("course",courseList); return
	 * "index"; }
	 */

	@RequestMapping("/update")
	public String updateProfile(@Valid @ModelAttribute("user") User user, BindingResult result) {
		if (result.hasErrors()) {
			return "Profile";
		}
		commonService.updateProfile(user);
		return "Profile";
	}

	@RequestMapping("/status")
	public String deactivateAccount(@RequestParam int id,BindingResult result, Model m){
		User user=userService.getUserById(id);
	//	System.out.println("dsfsdf"+user);
		user.setAccount_status("deactivate");
		loginService.saveUserDetails(user);
		
		//session.invalidate();
		return "login";
	}
	
	@RequestMapping("/showHistory")
	public String showHistory(@ModelAttribute("user") User user, Model obj) {
		String name = (String) session.getAttribute("username");
		User temp = loginService.userDetails(name);
		List<Transactions> historyDetails = userService.getHistoryDetails(temp);
		for (Transactions transactions : historyDetails) {
			System.out.println(transactions);
		}
		obj.addAttribute("transaction_list", historyDetails);

		return "History";
	}

	@RequestMapping("/showHome")
	public String showHome(@ModelAttribute() User user, ModelMap m) {
		List<Courses> courseList = coursesRepository.findAll();
		m.addAttribute("plist", courseList);
		return "user_home";
	}

	@RequestMapping("/logout")
	public String logout() {
		return "logout";
	}

}
