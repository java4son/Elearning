package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cts.model.Courses;
import com.cts.repository.CoursesRepository;
import com.cts.service.VendorService;

@Controller
public class VendorController {

	@Autowired
	VendorService vendorService;
	
	@RequestMapping("/addCourse")
	public String addCourse(@ModelAttribute Courses course){
		vendorService.addCourse(course);
		return "addCourse";
	}
}
