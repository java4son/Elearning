package com.cts.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.User;
import com.cts.model.*;
import com.cts.repository.CoursesRepository;
import com.cts.repository.ReviewRepository;
import com.cts.repository.TransactionRepository;
import com.cts.repository.UserRepository;

@Service
public class CommonService {
       
       @Autowired
       private UserRepository userRepository;
       
       @Autowired
       CoursesRepository courseRepository;
       
       @Autowired
       TransactionRepository transactionRepository;
       
       @Autowired
       ReviewRepository reviewRepository;
       
       public boolean updateProfile(User user) {
   		int age = user.getAge();
   		String contact = user.getContact();
   		String address = user.getAddress();
   		int id = user.getId();
   		userRepository.updateUserData(age,contact,address,id);
   		return true;
       }
   		
       public boolean deactivate(int userId){
              User tempUser = new User();
              tempUser=userRepository.findById(userId);
              tempUser.setAccount_status("deactivate");
              userRepository.save(tempUser);
              return true;
       }
       public List<Transactions> getTransactionList(int userId){
              return null;
       }
       
       public List<Courses> getCourseList(String cat,String what){
    	   List<Courses> courseList=null;
   		if(cat.equals("course_name")) {
   			courseList = courseRepository.findCourses(what);
   			
   		}
   		else if(cat.equals("vendor_id")) {
   			courseList = courseRepository.findCourses(Integer.parseInt(what));
   			
   		}
   		else {
   			courseList = courseRepository.findCoursesByCategory(what);
   			
   		}
    	   return courseList;
       }
       
       public List getAllData(String name){
    	   List list = null;
    	   list = transactionRepository.findAllTransactions(name);
    	   return list;
       }

       public List<Review> getReviewList(int course_id){
    	   return reviewRepository.findById(course_id);
       }
       
       public boolean saveReview(Review review) {
    	   reviewRepository.save(review);
    	   return true;}
       
       public Courses courseDetails(int id) {
    	   Courses course=courseRepository.findById(id);
		return course;
       }
       

}
