package com.cts.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.User;
import com.cts.model.*;
import com.cts.repository.UserRepository;

@Service
public class CommonService {
       
       @Autowired
       private UserRepository userRepository;
       
       public boolean updateProfile(User user){
              userRepository.save(user);
              return true;
       }
       public boolean deactivate(int userId){
              User tempUser = new User();
              tempUser=userRepository.findById(userId);
              tempUser.setAccount_status("deactivate");
              userRepository.save(tempUser);
              return true;
       }
       public List<Transactions> getTransactionList(int userId){
              return null;
       }

}
