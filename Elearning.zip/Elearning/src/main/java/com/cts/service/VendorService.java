package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Courses;
import com.cts.repository.CoursesRepository;

@Service
public class VendorService extends CommonService {

	@Autowired
	CoursesRepository coursesRepository;

	public List<Courses> vendorCourses(int id) {
		return courseRepository.findCourses(id);
	}

	public boolean activateAndDeactivateCourse(int course_id) {
		return true;
	}

	public boolean addCourse(Courses courses) {
		courseRepository.save(courses);
		return true;
	}

	public boolean updateCourse(Courses courses) {
		coursesRepository.save(courses);
		return true;
	}

	public boolean isVendors(int courseId, int id) {
		// TODO Auto-generated method stub
		if (coursesRepository.isVendors(courseId, id) != null)
			return true;

		return false;
	}
}
