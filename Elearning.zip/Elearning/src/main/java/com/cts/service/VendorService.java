package com.cts.service;

import com.cts.model.Courses;

public class VendorService extends CommonService {
	public boolean activateAndDeactivateCourse(int course_id){
		return true;
	}
	public Courses addCourse(Courses courses){
		return null;
	}
	public Courses updateCourse(Courses courses){
		return null;
	}
}
