package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Courses;
import com.cts.repository.CoursesRepository;

@Service
public class VendorService extends CommonService {
	
	@Autowired
	CoursesRepository coursesRepository;
	
	public boolean activateAndDeactivateCourse(int course_id){
		return true;
	}
	public Courses addCourse(Courses courses){
		return null;
	}
		
	public boolean updateCourse(Courses courses){
		coursesRepository.save(courses);
		return true;
	}
}
