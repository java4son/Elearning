package com.cts.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Courses;
import com.cts.model.Transactions;
import com.cts.model.User;
import com.cts.repository.TransactionRepository;
import com.cts.repository.UserRepository;

@Service
public class UserService extends CommonService {
       
       @Autowired
       TransactionRepository transactionRepository;
       @Autowired
       UserRepository userRepository;
       
       
       public boolean purchase(int course_id){
              return true;
       }
       
       public List<Transactions> getHistoryDetails(User user){
              int user_id=user.getId();
              System.out.println("user_id: "+user_id);
              return transactionRepository.findByUser_id(user_id);
       }
       
       public User getUserById(int id){
    	   return userRepository.getOne(id);
       }
       
       public List<User> getFilterList(String role){
    	   List<User> courseList=null;
    	   courseList = userRepository.findRole(role);
      		
    	   return courseList;
       }
       
       public int purchase(int user_id,int course_id){
    	   Transactions transOBJ=transactionRepository.findTransaction(user_id, course_id);
    	   if(transOBJ==null) {
    	   User user=getUserById(user_id);
    	   Courses course=courseDetails(course_id);
    	   Transactions t=new Transactions();
    	   t.setAmount(course.getPrice());
		   t.setCourse_id(course_id);
		   t.setDate(new Date());
		   t.setUser_id(user_id);
		   t.setVendor_id(course.getVendor_id());
    	   if(user.getMoney()>=course.getPrice()) {
    		   user.setMoney(user.getMoney()-course.getPrice());
    		   userRepository.save(user);
    		  
    		   t.setStatus("Successfull");
    		   transactionRepository.save(t);
              return 1;
    	   }
    	   
    	  
		   t.setStatus("Failed");
		   transactionRepository.save(t);
    	   return 0;}
    	   
    	   return -1;
       }


}
