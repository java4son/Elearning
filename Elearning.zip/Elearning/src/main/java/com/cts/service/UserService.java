package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Courses;
import com.cts.model.Transactions;
import com.cts.model.User;
import com.cts.repository.TransactionRepository;
import com.cts.repository.UserRepository;

@Service
public class UserService extends CommonService {
       
       @Autowired
       TransactionRepository transactionRepository;
       @Autowired
       UserRepository userRepository;
       
       
       public boolean purchase(int course_id){
              return true;
       }
       
       public List<Transactions> getHistoryDetails(User user){
              int user_id=user.getId();
              System.out.println("user_id: "+user_id);
              return transactionRepository.findByUser_id(user_id);
       }
       
       public User getUserById(int id){
    	   return userRepository.getOne(id);
       }
       
       public List<User> getFilterList(String role){
    	   List<User> courseList=null;
    	   courseList = userRepository.findRole(role);
      		
    	   return courseList;
       }
}
