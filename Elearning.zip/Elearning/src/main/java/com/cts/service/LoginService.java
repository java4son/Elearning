package com.cts.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.User;
import com.cts.repository.UserRepository;

@Service

public class LoginService {
       
       @Autowired
       private UserRepository userRepository;
       private String userName;
       private String password;
       User user = new User();
       public User userDetails(String userName){
              User user= userRepository.findByEmail(userName);
              //System.out.println(user);
              return user ;
       }
       public String getUserName(){
              userName=user.getEmail();
              return userName;
       }
       public String getPassword(){
              password=user.getPassword();
              return password;
       }
       public User saveUserDetails(User user){
    	   System.out.println("service"+user.getId());
    	   
              User userTemp;
              userRepository.updateAccountStatus(user.getAccount_status(), user.getId());
              userTemp=userRepository.getOne(user.getId());
              System.out.println("service"+userTemp);
              return userTemp;
       }
       

}

